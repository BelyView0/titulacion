from django.urls import path
from . import views

app_name = 'alumnos'

urlpatterns = [
    path('', views.DashboardAlumnoView.as_view(), name='dashboard'),
    path('expediente/', views.ExpedienteDetalleView.as_view(), name='expediente'),
    path('expediente/crear/', views.ExpedienteCreateView.as_view(), name='expediente_crear'),
    path('api/modalidades-por-plan/', views.ModalidadesPorPlanView.as_view(), name='modalidades_por_plan'),
    path('expediente/editar/<int:pk>/', views.ExpedienteUpdateView.as_view(), name='expediente_editar'),
    path('expediente/solicitar-revision/', views.SolicitarRevisionView.as_view(), name='solicitar_revision'),
    path('expediente/enviar-documentos/', views.EnviarDocumentosRevisionView.as_view(), name='enviar_documentos'),
    path('citas/<int:pk>/confirmar/', views.ConfirmarCitaView.as_view(), name='confirmar_cita'),
    path('citas/<int:pk>/reprogramar/', views.SolicitarReprogramacionCitaView.as_view(), name='reprogramar_cita'),
    path('expediente/subir-pago/', views.SubirComprobantePagoView.as_view(), name='subir_pago'),
    path('expediente/preficha-pago/', views.DescargarPrefichaPagoView.as_view(), name='descargar_preficha'),
    path('expediente/timeline/', views.TimelineView.as_view(), name='timeline'),
    path('documentos/<int:pk>/cargar/', views.DocumentoCargarView.as_view(), name='documento_cargar'),
    path('notificaciones/', views.NotificacionListView.as_view(), name='notificaciones'),
    path('confirmar-asistencia/', views.ConfirmarAsistenciaAlumnoView.as_view(), name='confirmar_asistencia'),
    path('expediente/oficio-jurado/', views.DescargarOficioJuradoAlumnoView.as_view(), name='descargar_oficio_jurado'),
    path('expediente/documentos-protocolo/', views.DescargarDocumentosProtocoloAlumnoView.as_view(), name='descargar_documentos_protocolo'),
    path('expediente/subir-acta-exencion/', views.SubirActaExencionView.as_view(), name='subir_acta_exencion'),
]

